﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace VladosKurs
{
    public partial class MainForm : Form
    {
        int[,] MS1, MS2, MR1, MR2;
        int KV1, KV2, Diam1, Diam2;
        string file;
        string[] Gr;

        public MainForm()
        {
            InitializeComponent();
        }


        void Input(ref int[,] MS, ref int KV, TextBox kolV, TextBox FO, RadioButton Fl)
        {

            if (Fl.Checked)
            {
                OFD.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                if (OFD.ShowDialog() == DialogResult.OK)
                {
                    file = OFD.FileName;
                    Gr = File.ReadAllLines(file);
                }
                else
                    throw new Exception("Ошибка выбора файла");
                kolV.Text = Gr[0];
                FO.Text = Gr[1];
            }
            KV = int.Parse(kolV.Text);
            string[] Fo = FO.Text.Split(new char[] { ' ' });
            MS = new int[KV, KV];
            int k = 0; int sz = 0; int y = 0;
            if (Fo[Fo.Length - 1] == "") y = 1;
            for (int i = 0; i < Fo.Length - y; i++)
            {
                if (Fo[i] == "0") k++;
                else
                {
                    int g = int.Parse(Fo[i]);
                    MS[k, g - 1] = 1;
                    sz++;
                }
            }
        }

        void Output(int[,] MS, DataGridView Dt, int KV)
        {
            Dt.ColumnCount = 0;
            Dt.Rows.Clear();
            Dt.ColumnCount = KV;
            Dt.Rows.Add(KV);
            for (int i = 0; i < KV; i++)
            {
                Dt.Columns[i].ReadOnly = true;
                Dt.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                Dt.Columns[i].Name = (i + 1).ToString();
                Dt.Columns[i].Width = 25;
            }
            for (int i = 0; i < KV; i++)
                for (int j = 0; j < KV; j++)
                    Dt.Rows[i].Cells[j].Value = MS[i, j];
        }

        int[,] MatrRasst(int[,] MS, int kv)
        {
            int[,] ResM = new int[kv, kv];
            for (int i = 0; i < kv; i++)
                for (int j = i; j < kv; j++)
                    if (i == j) ResM[i, j] = 0;
                    else
                    {
                        int[] Misp = new int[kv];
                        Misp[i] = 1; Misp[j] = 1;
                        if (MS[i, j] == 1) ResM[i, j] = 1;
                        else ResM[i, j] = Rasst(MS, i, j, kv, Misp);
                        ResM[j, i] = ResM[i, j];
                    }
            return ResM;
        }

        void Versh(int[,] Mrast, int kv, int Diam, int nomGr)
        {
            int kol;
            string Res = "     Граф №" + nomGr + Environment.NewLine;
            for (int i = 0; i < kv; i++)
                {
                    Res += Environment.NewLine + "Вершины " + (i + 1) + ": " + Environment.NewLine;
                    for (int a = 1; a <= Diam; a++)
                    {
                        kol = 0;
                        Res += "Расстояние = " + a + ": ";
                        for (int k = 0; k < kv; k++)
                            if (Mrast[i, k] == a)
                            {
                                Res += (k + 1).ToString() + " ";
                                kol++;
                            }
                        Res += "; Всего -  " + kol + Environment.NewLine;
                    }
                }
            StreamWriter save = new StreamWriter(@"Result" + nomGr + ".txt");
            save.Write(Res);
            save.Close();
        }

        int Rasst(int[,] MS, int st, int fin, int kv, int[] Misp)
        {
            int min, f;
            if (MS[st, fin] == 1) return 1;
            else
            {
                min = kv;
                for (int k = 0; k < kv; k++)
                    if ((MS[st, k] == 1) && (Misp[k] != 1))
                    {
                        f = 1;
                        Misp[k] = 1;
                        f += Rasst(MS, k, fin, kv, Misp);
                        if ((min > f) && (f > 0)) min = f;
                        Misp[k] = 0;
                    }
                if (min == kv) return -1;
                return min;
            }
        }

        int MaxDiam(int[,] MR, int kv)
        {
            int max = 0;
            for (int i = 0; i < kv; i++)
                for (int j = 0; j < kv; j++)
                    if (MR[i, j] > max) max = MR[i, j];
            return max;
        }

        private void Btn_Input1_Click(object sender, EventArgs e)
        {
            Input(ref MS1, ref KV1, TB_KV1, TB_FO1, RB_File1);
            Output(MS1, DtGrd1, KV1);
        }

        private void Btn_Input2_Click(object sender, EventArgs e)
        {
            Input(ref MS2, ref KV2, TB_KV2, TB_FO2, RB_File2);
            Output(MS2, DtGrd2, KV2);
        }

        private void Btn_Res_Click(object sender, EventArgs e)
        {
            MR1 = MatrRasst(MS1, KV1);
            MR2 = MatrRasst(MS2, KV2);
            Diam1 = MaxDiam(MR1, KV1);
            Diam2 = MaxDiam(MR2, KV2);
            Versh(MR1, KV1, Diam1, 1);
            Versh(MR2, KV2, Diam2, 2);
            Output(MR1, DtGrd1, KV1);
            Output(MR2, DtGrd2, KV2);
            Process.Start("C:\\Windows\\System32\\notepad.exe", @"Result1.txt");
            Process.Start("C:\\Windows\\System32\\notepad.exe", @"Result2.txt");
            if (Diam1 == Diam2)
                MessageBox.Show("Графы эквиваленты", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Графы не эквиваленты", "Результат", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}