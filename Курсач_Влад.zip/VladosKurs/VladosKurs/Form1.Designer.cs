﻿namespace VladosKurs
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RB_File1 = new System.Windows.Forms.RadioButton();
            this.RB_Key1 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Input1 = new System.Windows.Forms.Button();
            this.TB_FO1 = new System.Windows.Forms.TextBox();
            this.TB_KV1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RB_Key2 = new System.Windows.Forms.RadioButton();
            this.RB_File2 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.Btn_Input2 = new System.Windows.Forms.Button();
            this.TB_FO2 = new System.Windows.Forms.TextBox();
            this.TB_KV2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.DtGrd1 = new System.Windows.Forms.DataGridView();
            this.DtGrd2 = new System.Windows.Forms.DataGridView();
            this.Btn_Res = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.SFD = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtGrd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtGrd2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RB_File1);
            this.groupBox1.Controls.Add(this.RB_Key1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Btn_Input1);
            this.groupBox1.Controls.Add(this.TB_FO1);
            this.groupBox1.Controls.Add(this.TB_KV1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 252);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(591, 99);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Граф № 1";
            // 
            // RB_File1
            // 
            this.RB_File1.AutoSize = true;
            this.RB_File1.Location = new System.Drawing.Point(494, 16);
            this.RB_File1.Name = "RB_File1";
            this.RB_File1.Size = new System.Drawing.Size(54, 17);
            this.RB_File1.TabIndex = 8;
            this.RB_File1.Text = "Файл";
            this.RB_File1.UseVisualStyleBackColor = true;
            // 
            // RB_Key1
            // 
            this.RB_Key1.AutoSize = true;
            this.RB_Key1.Checked = true;
            this.RB_Key1.Location = new System.Drawing.Point(377, 16);
            this.RB_Key1.Name = "RB_Key1";
            this.RB_Key1.Size = new System.Drawing.Size(84, 17);
            this.RB_Key1.TabIndex = 7;
            this.RB_Key1.TabStop = true;
            this.RB_Key1.Text = "Клавиатура";
            this.RB_Key1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Режим ввода:";
            // 
            // Btn_Input1
            // 
            this.Btn_Input1.Location = new System.Drawing.Point(6, 70);
            this.Btn_Input1.Name = "Btn_Input1";
            this.Btn_Input1.Size = new System.Drawing.Size(579, 23);
            this.Btn_Input1.TabIndex = 4;
            this.Btn_Input1.Text = "Ввод графа";
            this.Btn_Input1.UseVisualStyleBackColor = true;
            this.Btn_Input1.Click += new System.EventHandler(this.Btn_Input1_Click);
            // 
            // TB_FO1
            // 
            this.TB_FO1.Location = new System.Drawing.Point(117, 42);
            this.TB_FO1.Name = "TB_FO1";
            this.TB_FO1.Size = new System.Drawing.Size(468, 20);
            this.TB_FO1.TabIndex = 3;
            // 
            // TB_KV1
            // 
            this.TB_KV1.Location = new System.Drawing.Point(117, 16);
            this.TB_KV1.Name = "TB_KV1";
            this.TB_KV1.Size = new System.Drawing.Size(117, 20);
            this.TB_KV1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Количество вершин:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "FO-представление";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RB_Key2);
            this.groupBox2.Controls.Add(this.RB_File2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Btn_Input2);
            this.groupBox2.Controls.Add(this.TB_FO2);
            this.groupBox2.Controls.Add(this.TB_KV2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(12, 357);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(591, 99);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Граф № 2";
            // 
            // RB_Key2
            // 
            this.RB_Key2.AutoSize = true;
            this.RB_Key2.Checked = true;
            this.RB_Key2.Location = new System.Drawing.Point(377, 19);
            this.RB_Key2.Name = "RB_Key2";
            this.RB_Key2.Size = new System.Drawing.Size(84, 17);
            this.RB_Key2.TabIndex = 9;
            this.RB_Key2.TabStop = true;
            this.RB_Key2.Text = "Клавиатура";
            this.RB_Key2.UseVisualStyleBackColor = true;
            // 
            // RB_File2
            // 
            this.RB_File2.AutoSize = true;
            this.RB_File2.Location = new System.Drawing.Point(494, 19);
            this.RB_File2.Name = "RB_File2";
            this.RB_File2.Size = new System.Drawing.Size(54, 17);
            this.RB_File2.TabIndex = 10;
            this.RB_File2.Text = "Файл";
            this.RB_File2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(293, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Режим ввода:";
            // 
            // Btn_Input2
            // 
            this.Btn_Input2.Location = new System.Drawing.Point(6, 70);
            this.Btn_Input2.Name = "Btn_Input2";
            this.Btn_Input2.Size = new System.Drawing.Size(579, 23);
            this.Btn_Input2.TabIndex = 4;
            this.Btn_Input2.Text = "Ввод графа";
            this.Btn_Input2.UseVisualStyleBackColor = true;
            this.Btn_Input2.Click += new System.EventHandler(this.Btn_Input2_Click);
            // 
            // TB_FO2
            // 
            this.TB_FO2.Location = new System.Drawing.Point(117, 42);
            this.TB_FO2.Name = "TB_FO2";
            this.TB_FO2.Size = new System.Drawing.Size(468, 20);
            this.TB_FO2.TabIndex = 3;
            // 
            // TB_KV2
            // 
            this.TB_KV2.Location = new System.Drawing.Point(117, 16);
            this.TB_KV2.Name = "TB_KV2";
            this.TB_KV2.Size = new System.Drawing.Size(117, 20);
            this.TB_KV2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Количество вершин:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "FO-представление";
            // 
            // DtGrd1
            // 
            this.DtGrd1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtGrd1.Location = new System.Drawing.Point(12, 38);
            this.DtGrd1.Name = "DtGrd1";
            this.DtGrd1.Size = new System.Drawing.Size(240, 208);
            this.DtGrd1.TabIndex = 6;
            // 
            // DtGrd2
            // 
            this.DtGrd2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DtGrd2.Location = new System.Drawing.Point(363, 38);
            this.DtGrd2.Name = "DtGrd2";
            this.DtGrd2.Size = new System.Drawing.Size(240, 208);
            this.DtGrd2.TabIndex = 7;
            // 
            // Btn_Res
            // 
            this.Btn_Res.Location = new System.Drawing.Point(258, 38);
            this.Btn_Res.Name = "Btn_Res";
            this.Btn_Res.Size = new System.Drawing.Size(99, 23);
            this.Btn_Res.TabIndex = 8;
            this.Btn_Res.Text = "Рассчитать";
            this.Btn_Res.UseVisualStyleBackColor = true;
            this.Btn_Res.Click += new System.EventHandler(this.Btn_Res_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.Location = new System.Drawing.Point(258, 67);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(99, 23);
            this.Btn_Exit.TabIndex = 9;
            this.Btn_Exit.Text = "Выход";
            this.Btn_Exit.UseVisualStyleBackColor = true;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(560, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Для каждой вершины рассчитать количество вершин, удаленных от заданной на определ" +
    "енное расстояние ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "по кратчайшим путям.";
            // 
            // OFD
            // 
            this.OFD.FileName = "openFileDialog1";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 461);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Res);
            this.Controls.Add(this.DtGrd2);
            this.Controls.Add(this.DtGrd1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "Денисов Владислав, 611 пст., курсовой проект";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DtGrd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DtGrd2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RB_File1;
        private System.Windows.Forms.RadioButton RB_Key1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Input1;
        private System.Windows.Forms.TextBox TB_FO1;
        private System.Windows.Forms.TextBox TB_KV1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RB_Key2;
        private System.Windows.Forms.RadioButton RB_File2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Btn_Input2;
        private System.Windows.Forms.TextBox TB_FO2;
        private System.Windows.Forms.TextBox TB_KV2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView DtGrd1;
        private System.Windows.Forms.DataGridView DtGrd2;
        private System.Windows.Forms.Button Btn_Res;
        private System.Windows.Forms.Button Btn_Exit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.SaveFileDialog SFD;
    }
}

